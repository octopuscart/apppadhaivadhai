<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css" rel="stylesheet" />
<link href="http://fonts.googleapis.com/css?family=Lato:100,300,400,700,900,100italic,300italic,400italic" rel="stylesheet" type="text/css" />
<style type="text/css">div{
        font-family:lato;
    }
</style>
<div style="    margin: 0px;
     padding: 30px;
     font: 300 lato;
     background-color: #E2E2E2;">
    <div style="    padding: 20px;;background:#fff">
        <!--end of upper level header-->
        
        
        <!--internal header-->
        <table align="center" border="0" cellpadding="0" cellspacing="0" style="padding: 24px; background-color: white;" width="100%">
            <tbody>
                <tr>
                    <td>
                        <table align="center" border="0" cellpadding="0" cellspacing="0" style="    width: 100%;">
                            <tbody>
                                <tr style="background-color: #FFF;">
                                    <td style="width:50%;    padding: 10px;"><img src="http://costcointernational.com/frontend/assets/images/logo/nf_logo_8.png" style="height:70px; width:141px;" /></td>
                                    <td style="text-align: right;
                                        font-family: Arial,Helvetica,sans-serif;
                                        font-size: 18px;
                                        /* border-right: 5px solid #FFF; */
                                        padding: 14px;
                                        /* background-color: #E4E4E4; */
                                        width: 245px;
                                        color: #444;" width="">&nbsp;</td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
            </tbody>
        </table>
        <!--end of internal header-->
        

        <table align="center" border="0" cellpadding="0" cellspacing="0" style="    width: 100%;">
            <tbody>
                <tr>
                    <td colspan="3" height="10" style="border-bottom: 1px  solid  #eaedef;">&nbsp;</td>
                </tr>
                <tr>
                    <td colspan="3" readonly="readonly"><span readonly="readonly" style="
                                                              text-align: center;
                                                              width: 100%;
                                                              font-size: 24px;
                                                              float: left;
                                                              border-bottom: 1px solid #eaedef;
                                                              margin-bottom: 20px;
                                                              padding: 20px 0;
                                                              background-color: #000;
                                                              color: #fff;">Nita Fashions </span></td>
                </tr>
            </tbody>
        </table>

        <p>Hello Dear,</p>

        <p>Most respected names in men&#39;s clothing, meticulous hand tailoring, and quality that is becoming harder and harder to find. Our Master Tailor, Peter Daswani, has over 30 years of experience in custom tailoring. World&#39;s finest fabrics are careful selected to live up to name of Fashions.&nbsp;</p>

        <div style="height:200px">Sincerely,<br />
            <b>Nita Fashions</b><br />
            <span style="float:left;width:255px">16 Mody Road, G/F, T. S. T, Kowloon,<br />
                Hong Kong<br />
                T: + (852) 27219990, 27219991,<br />
                F: +852 27234886,<br />
                E: sales@nitafashions.com<br />
                W: www.nitafashions.com </span></div>

        <div style="height:200px"><span style="color: #7b808f; font-family: Arial, Helvetica, sans-serif; font-size: 11px; line-height: 18px; text-align: justify; ">If you do not want to receive this mailer,&nbsp;</span><a href="---userlink---" style="color:#7b808f; font-family: Arial, Helvetica, sans-serif; font-size: 11px; line-height: 18px; text-align: justify;    text-decoration: underline;
                                                                                                                                                                                                        " target="_blank">Unsubscribe</a></div>
